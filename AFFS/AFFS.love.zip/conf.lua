function love.conf(t)
  t.window.fullscreen = true
  t.window.title = "Ananas fall from the sky"
end
